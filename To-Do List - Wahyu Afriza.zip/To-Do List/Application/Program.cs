using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using StackExchange.Redis;
using Core;
using Core.Features; // Ensure this is the correct namespace for TokenBlacklistService
using Core.Services; // Ensure this is the correct namespace for TokenService
using Persistence;
using System.Text;
using System.Threading.Tasks; // Add this using directive

internal class Program
{
    private static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        // Add services to the container.
        builder.Services.AddApplicationServices();
        builder.Services.AddControllers();
        builder.Services.AddEndpointsApiExplorer();
        builder.Services.AddSwaggerGen();
        builder.Services.AddPersistenceServices();

        // Register services
        builder.Services.AddScoped<ITokenBlacklistService, TokenBlacklistService>(); // Register the blacklist service
        builder.Services.AddScoped<TokenService>(); // Register the TokenService

        // JWT Authentication Configuration
        var jwtSettings = builder.Configuration.GetSection("JwtSettings").Get<JwtSettings>();
        builder.Services.AddSingleton(jwtSettings);

        builder.Services.AddAuthentication(options =>
        {
            options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
            options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
        })
        .AddJwtBearer(options =>
        {
            options.TokenValidationParameters = new TokenValidationParameters
            {
                ValidateIssuer = true,
                ValidateAudience = true,
                ValidateLifetime = true,
                ValidateIssuerSigningKey = true,
                ValidIssuer = jwtSettings.Issuer,
                ValidAudience = jwtSettings.Audience,
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSettings.Key))
            };

            // Set the Events property on the JwtBearerOptions object
            options.Events = new JwtBearerEvents
            {
                OnMessageReceived = context =>
                {
                    // Check if the token is blacklisted
                    var tokenBlacklistService = context.HttpContext.RequestServices.GetRequiredService<ITokenBlacklistService>();
                    var token = context.Request.Headers["Authorization"].ToString().Replace("Bearer ", "");
                    if (tokenBlacklistService.IsBlacklisted(token))
                    {
                        context.Fail("Token is blacklisted");
                    }
                    return Task.CompletedTask;
                }
            };
        });

        // Redis Configuration
        builder.Services.AddSingleton<IConnectionMultiplexer>(ConnectionMultiplexer.Connect(builder.Configuration.GetValue<string>("Redis:Configuration")));
        builder.Services.AddScoped(typeof(RedisService<>));

        // MySQL Configuration
        builder.Services.AddDbContext<ApplicationDbContext>(options =>
            options.UseMySql(builder.Configuration.GetConnectionString("DefaultConnection"),
                new MySqlServerVersion(new Version(8, 0, 21))));

        var app = builder.Build();

        // Configure the HTTP request pipeline.
        if (app.Environment.IsDevelopment())
        {
            app.UseSwagger();
            app.UseSwaggerUI();
        }

        app.UseHttpsRedirection();
        app.UseAuthentication();  // Ensure this is added before UseAuthorization
        app.UseAuthorization();

        app.MapControllers();

        app.Run();
    }
}