﻿using System;
using System.Collections.Generic;

namespace Application.Features.Requests
{
    public class AddToDoDetailRequest
    {
        public List<ToDoDetailDto> ToDoDetails { get; set; } = new List<ToDoDetailDto>();
    }

    public class ToDoDetailDto
    {
        public Guid TodoDetailId { get; set; } // Unique identifier for the detail
        public Guid ToDoId { get; set; } // ToDoId for linking details
        public string Activity { get; set; } // Description of the activity
        public string Category { get; set; } // Category of the detail
        public string DetailNote { get; set; } // Additional notes for the detail
    }
}