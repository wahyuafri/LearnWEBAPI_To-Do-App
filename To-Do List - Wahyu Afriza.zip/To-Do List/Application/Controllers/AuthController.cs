using Microsoft.AspNetCore.Mvc;
using Persistence.Models;
using Core.Services; // Ensure this matches the actual namespace of TokenService

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly TokenService _tokenService;
    private readonly RedisService<string> _redisService;

    public AuthController(TokenService tokenService, RedisService<string> redisService)
    {
        _tokenService = tokenService;
        _redisService = redisService;
    }

    [HttpPost("login")]
    public IActionResult Login([FromBody] User user)
    {
        // Replace with actual user validation
        if (user.Username == "admin" && user.Password == "admin")
        {
            user.IsAdmin = true;
        }
        else if (user.Username == "user" && user.Password == "user")
        {
            user.IsAdmin = false;
        }
        else
        {
            return Unauthorized("Invalid credentials");
        }

        var token = _tokenService.GenerateToken(user);
        return Ok(new { token });
    }

    [HttpPost("logout")]
    public async Task<IActionResult> Logout()
    {
        var username = User.Identity?.Name;
        if (username != null)
        {
            await _redisService.SetAsync(username, "invalid");
        }
        return Ok();
    }
}