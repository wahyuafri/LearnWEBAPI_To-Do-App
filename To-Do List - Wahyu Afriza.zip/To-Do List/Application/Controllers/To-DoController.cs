﻿using Application.Features.Requests;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Persistence.Models;

namespace Application.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ToDoController : ControllerBase
    {
        private readonly RedisService<List<ToDo>> _redisService;

        public ToDoController(RedisService<List<ToDo>> redisService)
        {
            _redisService = redisService;
        }

        // 1. Get All Todos - Public access without login
        [HttpGet("all")]
        [AllowAnonymous]
        public async Task<IActionResult> GetAll()
        {
            var todos = await _redisService.GetAsync("todos");
            return Ok(todos ?? new List<ToDo>());
        }

        // 2. Add To-Do - Requires a body request
        [HttpPost("add")]
        [Authorize]
        public async Task<IActionResult> Add([FromBody] ToDo toDo)
        {
            var todos = await _redisService.GetAsync("todos") ?? new List<ToDo>();
            todos.Add(toDo);
            await _redisService.SetAsync("todos", todos);
            return Ok(todos);
        }

        // 3. Add To-Do Detail - Bulk add, requires a body request
        [HttpPost("addDetail")]
        [Authorize]
        public async Task<IActionResult> AddToDoDetail([FromBody] AddToDoDetailRequest request)
        {
            var todos = await _redisService.GetAsync("todos") ?? new List<ToDo>();

            foreach (var detail in request.ToDoDetails)
            {
                var toDo = todos.FirstOrDefault(t => t.TodoId == detail.ToDoId);
                if (toDo != null)
                {
                    toDo.ToDoDetails.Add(new ToDoDetail
                    {
                        TodoDetailId = detail.TodoDetailId,
                        Activity = detail.Activity,
                        DetailNote = detail.DetailNote,
                        Category = detail.Category
                    });
                }
            }

            await _redisService.SetAsync("todos", todos);
            return Ok(todos);
        }

        // 4. Delete To-Do - Admin-only access, requires a ToDo ID
        [HttpDelete("delete/{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(Guid id)
        {
            var todos = await _redisService.GetAsync("todos") ?? new List<ToDo>();
            var todoToRemove = todos.FirstOrDefault(t => t.TodoId == id);
            if (todoToRemove != null)
            {
                todos.Remove(todoToRemove);
                await _redisService.SetAsync("todos", todos);
            }
            return Ok(todos);
        }

        // 5. Delete To-Do Detail - Admin-only access, requires a ToDoDetail ID
        [HttpDelete("deleteDetail/{todoDetailId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteToDoDetail(Guid todoDetailId)
        {
            var todos = await _redisService.GetAsync("todos") ?? new List<ToDo>();

            foreach (var toDo in todos)
            {
                var detailToRemove = toDo.ToDoDetails.FirstOrDefault(d => d.TodoDetailId == todoDetailId);
                if (detailToRemove != null)
                {
                    toDo.ToDoDetails.Remove(detailToRemove);
                    break;
                }
            }

            await _redisService.SetAsync("todos", todos);
            return Ok(todos);
        }
    }
}