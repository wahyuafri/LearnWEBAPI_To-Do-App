﻿namespace Core.Features
{
    public interface ITokenBlacklistService
    {
        bool IsBlacklisted(string token);
        void AddToBlacklist(string token);
    }
}