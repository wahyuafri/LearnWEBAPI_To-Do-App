using MediatR;
using Persistence.DatabaseContext;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Core.Features.Queries.GetToDo
{
    public class GetToDoQuery : IRequest<List<GetToDoResponse>> { }

    public class GetToDoResponse
    {
        public Guid TodoId { get; set; } // Changed to match the schema
        public string Day { get; set; }
        public DateTime TodayDate { get; set; }
        public string Note { get; set; }
        public int DetailCount { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public ICollection<GetToDoDetailResponse> ToDoDetails { get; set; }
    }

    public class GetToDoDetailResponse
    {
        public Guid TodoDetailId { get; set; } // Changed to match the schema
        public string Activity { get; set; }
        public string Category { get; set; }
        public string DetailNote { get; set; }
    }

    public class GetToDoHandler : IRequestHandler<GetToDoQuery, List<GetToDoResponse>>
    {
        private readonly TableContext _context;

        public GetToDoHandler(TableContext context)
        {
            _context = context;
        }

        public async Task<List<GetToDoResponse>> Handle(GetToDoQuery query, CancellationToken cancellationToken)
        {
            var toDos = await _context.ToDos
                .Include(t => t.ToDoDetails)
                .AsNoTracking()
                .ToListAsync(cancellationToken);

            var response = toDos.Select(toDo => new GetToDoResponse
            {
                TodoId = toDo.TodoId,
                Day = toDo.Day,
                TodayDate = toDo.TodayDate,
                Note = toDo.Note,
                DetailCount = toDo.DetailCount,
                CreatedDate = toDo.CreatedDate,
                UpdatedDate = toDo.UpdatedDate,
                ToDoDetails = toDo.ToDoDetails.Select(detail => new GetToDoDetailResponse
                {
                    TodoDetailId = detail.TodoDetailId,
                    Activity = detail.Activity,
                    Category = detail.Category,
                    DetailNote = detail.DetailNote
                }).ToList()
            }).ToList();

            return response;
        }
    }
}
