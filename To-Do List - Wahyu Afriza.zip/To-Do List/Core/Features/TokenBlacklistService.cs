﻿using System.Collections.Generic;
using Core.Features;

namespace Core.Features
{
    public class TokenBlacklistService : ITokenBlacklistService
    {
        private readonly HashSet<string> _blacklistedTokens = new HashSet<string>();

        public bool IsBlacklisted(string token) => _blacklistedTokens.Contains(token);

        public void AddToBlacklist(string token)
        {
            _blacklistedTokens.Add(token);
        }
    }
}