using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Persistence.DatabaseContext;

namespace Persistence
{
    public static class PersistenceRegistration
    {
        public static IServiceCollection AddPersistenceServices(this IServiceCollection services)
        {
            const string dbConnection = "server=localhost;port=3306;database=TO-DO;user=root;password=;";

            // Update to use your DbContext and connection string
            services.AddDbContext<TableContext>(opt => opt.UseMySql(dbConnection,
                new MySqlServerVersion(new Version(8, 0, 21))));

            // Remove the registration for TableSpecificationRepository and its interface
            // services.AddScoped<ITableSpecificationRepository, TableSpecificationRepository>();

            // Add other repositories or services here if necessary

            return services;
        }
    }
}
