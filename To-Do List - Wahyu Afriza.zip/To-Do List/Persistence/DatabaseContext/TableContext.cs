﻿using Microsoft.EntityFrameworkCore;
using Persistence.Models; // Assuming your models are in the Persistence.Models namespace

namespace Persistence.DatabaseContext;

public class TableContext : DbContext
{
    public TableContext(DbContextOptions<TableContext> options) : base(options)
    {
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.EnableDetailedErrors();
    }

    // DbSet properties for your entities
    public DbSet<ToDo> ToDos { get; set; }
    public DbSet<User> Users { get; set; }
}