using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Persistence.Models
{
    public class User
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(50)] // Set a maximum length for usernames
        public string Username { get; set; }

        [Required]
        [MaxLength(100)] // Set a maximum length for passwords
        public string Password { get; set; }

        public bool IsAdmin { get; set; }
    }

    public class ToDo
    {
        [Key]
        public Guid TodoId { get; set; } // Primary key

        [Required]
        [MaxLength(50)]
        public string Day { get; set; } // Day of the week

        [Required]
        public DateTime TodayDate { get; set; } // Date for the ToDo item

        [Required]
        [MaxLength(255)]
        public string Note { get; set; } // Description or note about the ToDo item

        public int DetailCount { get; set; } // Number of details related to this ToDo

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow; // Default to current time in UTC

        public DateTime UpdatedDate { get; set; } = DateTime.UtcNow; // Default to current time in UTC

        // Navigation property for related ToDoDetails
        public ICollection<ToDoDetail> ToDoDetails { get; set; } = new List<ToDoDetail>();
    }

    public class ToDoDetail
    {
        [Key]
        public Guid TodoDetailId { get; set; } // Primary key

        [Required]
        [MaxLength(100)]
        public string Activity { get; set; } // Activity related to the ToDo

        [Required]
        [MaxLength(50)]
        public string Category { get; set; } // Category of the detail

        [Required]
        [MaxLength(255)]
        public string DetailNote { get; set; } // Additional notes for the detail

        [Required]
        [ForeignKey("ToDo")]
        public Guid TodoId { get; set; } // Foreign key reference to the ToDo

        // Navigation property for the related ToDo
        public ToDo ToDo { get; set; }

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow; // Default to current time in UTC

        public DateTime UpdatedDate { get; set; } = DateTime.UtcNow; // Default to current time in UTC
    }
}